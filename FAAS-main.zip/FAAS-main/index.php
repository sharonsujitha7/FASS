<?php $title="Home"; include 'include/header.php'; ?>

<div class="page-wrraper">
    <section id="main" class="section bg-light text-center text-white">
        <div class="inner-content-main">
            <div class="container">
                <h1 class="text-capitalize mt-3">Welcome to (FAASRTS)</h1>

           

                <div class="buttons mt-5">
                    <a href="admin/" class="btn btn-primary text-capitalize">ADMIN</a>
                    <a href="farmer/" class="btn btn-primary text-capitalize">FARMER</a>
                    <a href="supplier/" class="btn btn-primary text-capitalize">SUPPLIER</a>
                </div>
            </div>
        </div>
    </section>
    <?php include 'include/footer.php'; ?>
</div>
