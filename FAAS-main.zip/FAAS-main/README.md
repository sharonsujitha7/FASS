# FAAS
India is the leading producer of multiple crops, and agriculture is one of its most important economic activities.
Our website provides services for the ease of Farmers,
Our Website link:http://faasrts.epizy.com/index.php

We have created a website to enable direct commuincation between farmers and suppliers with no intermediate person.

In this way,the farmers can pitch their suppliers with their prices and the clients can purchase the desired products in those specified locations.

In both ways, there would be satisfaction to farmers and suppliers.


