<?php $title="Boosters"; include 'include/header.php'; ?>
	<section id="boosters" class=" text-center bg-02" style="padding: 5em 0; min-height: 90vh;">
		<div class="section-inner padding-top-bottom">
			<div class="container">
				<div class="row">
					<?php get_all_boosters_boodters("bg-01") ?>
				</div>
			</div>
		</div>
	</section>
<?php include 'include/footer.php'; ?>